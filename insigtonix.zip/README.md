# Insightonix Academic Journal

A professional Scopus-level journal website built with React, Express, and Prisma (MySQL).

## Features

- **Public Interface**:
  - Home page with journal overview and latest issue
  - Issue archives
  - Article details with PDF download
  - Editorial Board listing
  - Contact information
- **Admin Dashboard**:
  - Secure login
  - Manage Issues (Create, Edit, Delete)
  - Manage Articles
  - Manage Editorial Board Members
  - Update Site Settings (Title, ISSN, etc.)

## Prerequisites

- Node.js (v18+)
- MySQL Database

## Setup

1. **Install Dependencies**
   ```bash
   npm install
   ```

2. **Configure Database**
   - Create a `.env` file in the root directory (copy from `.env.example` if available, or create new).
   - Add your MySQL connection string:
     ```env
     DATABASE_URL="mysql://USER:PASSWORD@HOST:PORT/DATABASE"
     JWT_SECRET="your-secure-secret-key"
     ```

3. **Initialize Database**
   Push the schema to your database:
   ```bash
   npx prisma db push
   ```
   
   *Note: This will create the necessary tables.*

4. **Seed/Create Admin User**
   The first time you log in, use the default credentials if the database is empty (check `api/routes/auth.ts` logic or seed manually):
   - Ideally, insert an admin user into the `admins` table manually or use a seed script.
   - Default fallback login logic is implemented for `admin` / `admin123` if no user exists (for development).

## Running the Application

Start both the frontend and backend server concurrently:

```bash
npm run dev
```

- Frontend: http://localhost:5173
- Backend API: http://localhost:3001

## Project Structure

- `src/`: React Frontend
  - `pages/`: Page components
  - `components/`: Reusable components
  - `lib/`: Utilities and API wrapper
  - `store/`: State management (Zustand)
- `api/`: Express Backend
  - `routes/`: API endpoints
  - `middleware/`: Auth middleware
  - `prisma.ts`: Prisma client instance
- `prisma/`: Database Schema

## Tech Stack

- **Frontend**: React, Tailwind CSS, Lucide Icons, Zustand
- **Backend**: Express.js
- **Database**: MySQL, Prisma ORM
- **Tooling**: Vite, TypeScript
