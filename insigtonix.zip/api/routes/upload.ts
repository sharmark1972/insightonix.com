
import { Router, type Request, type Response } from 'express'
import multer from 'multer'
import path from 'path'
import fs from 'fs'
import { authenticateToken } from '../middleware/auth.js'

// Extend Express Request to include Multer file
interface MulterRequest extends Request {
  file?: Express.Multer.File
}

const router = Router()

// Configure storage
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    const uploadDir = 'uploads/'
    // Create directory if it doesn't exist
    if (!fs.existsSync(uploadDir)) {
      fs.mkdirSync(uploadDir, { recursive: true })
    }
    cb(null, uploadDir)
  },
  filename: function (req, file, cb) {
    // Generate unique filename
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9)
    cb(null, file.fieldname + '-' + uniqueSuffix + path.extname(file.originalname))
  }
})

// File filter
const fileFilter = (req: any, file: any, cb: any) => {
  // Accept images only
  if (!file.originalname.match(/\.(jpg|jpeg|png|gif|webp)$/)) {
    return cb(new Error('Only image files are allowed!'), false)
  }
  cb(null, true)
}

const upload = multer({ 
  storage: storage,
  fileFilter: fileFilter,
  limits: {
    fileSize: 5 * 1024 * 1024 // 5MB limit
  }
})

// PDF file filter
const pdfFileFilter = (req: any, file: any, cb: any) => {
  if (!file.originalname.match(/\.pdf$/i)) {
    return cb(new Error('Only PDF files are allowed!'), false)
  }
  cb(null, true)
}

const pdfUpload = multer({
  storage: storage,
  fileFilter: pdfFileFilter,
  limits: {
    fileSize: 20 * 1024 * 1024 // 20MB limit
  }
})

// Upload endpoint
router.post('/', authenticateToken, upload.single('image'), (req: MulterRequest, res: Response): void => {
  try {
    if (!req.file) {
      res.status(400).json({ success: false, error: 'No file uploaded' })
      return
    }

    // Return the public URL
    // Assuming uploads are served from root/uploads
    const fileUrl = `/uploads/${req.file.filename}`
    
    res.json({ 
      success: true, 
      data: { 
        url: fileUrl,
        filename: req.file.filename
      } 
    })
  } catch (error) {
    console.error('Upload error:', error)
    res.status(500).json({ success: false, error: 'Failed to upload file' })
  }
})

// PDF Upload endpoint
router.post('/pdf', authenticateToken, pdfUpload.single('pdf'), (req: MulterRequest, res: Response): void => {
  try {
    if (!req.file) {
      res.status(400).json({ success: false, error: 'No file uploaded' })
      return
    }

    const fileUrl = `/uploads/${req.file.filename}`

    res.json({
      success: true,
      data: {
        url: fileUrl,
        filename: req.file.filename,
        originalName: req.file.originalname
      }
    })
  } catch (error) {
    console.error('PDF upload error:', error)
    res.status(500).json({ success: false, error: 'Failed to upload PDF' })
  }
})

export default router
